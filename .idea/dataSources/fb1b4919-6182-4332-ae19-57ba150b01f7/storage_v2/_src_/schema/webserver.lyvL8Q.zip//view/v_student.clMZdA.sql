create definer = root@localhost view v_student as
select `v`.`INS_ID`     AS `INS_ID`,
       `v`.`INS_NAME`   AS `INS_NAME`,
       `v`.`MAJOR_ID`   AS `MAJOR_ID`,
       `v`.`MAJOR_NAME` AS `MAJOR_NAME`,
       `v`.`CLASS_ID`   AS `CLASS_ID`,
       `s`.`STU_ID`     AS `STU_ID`,
       `s`.`STU_NAME`   AS `STU_NAME`,
       `s`.`STU_AGE`    AS `STU_AGE`,
       `s`.`STU_GENDER` AS `STU_GENDER`
from `webserver`.`student` `s`
         join `webserver`.`v_ins_maj_cla` `v`
where (`s`.`CLASS_ID` = `v`.`CLASS_ID`);

