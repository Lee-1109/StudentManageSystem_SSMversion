create
    definer = root@localhost procedure proc_stuGetOneCourseGrade(IN V_CID varchar(255), IN V_SID varchar(255))
begin
select v.COUR_ID,v.COUR_NAME,v.CLASS_ID,v.STU_ID,v.STU_NAME,v.GRADE FROM v_grade v
where v.COUR_ID=V_CID and v.STU_ID=V_SID;
end;

