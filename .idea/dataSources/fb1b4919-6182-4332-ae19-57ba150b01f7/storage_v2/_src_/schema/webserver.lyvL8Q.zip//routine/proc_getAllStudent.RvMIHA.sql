create
    definer = root@localhost procedure proc_getAllStudent()
begin
 select STU_ID,STU_NAME,CLASS_ID,STU_AGE,STU_GENDER from student;
end;

