create definer = root@localhost view v_grade as
select `c`.`COUR_ID`   AS `COUR_ID`,
       `c`.`COUR_NAME` AS `COUR_NAME`,
       `s`.`CLASS_ID`  AS `CLASS_ID`,
       `s`.`STU_ID`    AS `STU_ID`,
       `s`.`STU_NAME`  AS `STU_NAME`,
       `r`.`GRADE`     AS `GRADE`
from `webserver`.`course` `c`
         join `webserver`.`student` `s`
         join `webserver`.`report` `r`
where ((`r`.`COUR_ID` = `c`.`COUR_ID`) and (`r`.`STU_ID` = `s`.`STU_ID`));

