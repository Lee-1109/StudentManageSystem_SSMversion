create definer = root@localhost trigger tg_delete_teacher_login
    after delete
    on teacher
    for each row
begin
delete from login where ID = old.TEA_ID;
end;

