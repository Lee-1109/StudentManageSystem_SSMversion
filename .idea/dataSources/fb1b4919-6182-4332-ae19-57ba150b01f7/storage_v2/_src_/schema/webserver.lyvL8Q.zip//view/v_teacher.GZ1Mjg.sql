create definer = root@localhost view v_teacher as
select `v`.`INS_ID`     AS `INS_ID`,
       `v`.`INS_NAME`   AS `INS_NAME`,
       `v`.`MAJOR_ID`   AS `MAJOR_ID`,
       `v`.`MAJOR_NAME` AS `MAJOR_NAME`,
       `t`.`TEA_ID`     AS `TEA_ID`,
       `t`.`TEA_NAME`   AS `TEA_NAME`,
       `t`.`TEA_GENDER` AS `TEA_GENDER`,
       `t`.`TEA_AGE`    AS `TEA_AGE`
from `webserver`.`teacher` `t`
         join `webserver`.`v_ins_maj` `v`
where (`v`.`MAJOR_ID` = `t`.`MAJOR_ID`);

