create definer = root@localhost view v_ins_maj_cla as
select `i`.`INS_ID`     AS `INS_ID`,
       `i`.`INS_NAME`   AS `INS_NAME`,
       `m`.`MAJOR_ID`   AS `MAJOR_ID`,
       `m`.`MAJOR_NAME` AS `MAJOR_NAME`,
       `c`.`CLASS_ID`   AS `CLASS_ID`
from `webserver`.`institute` `i`
         join `webserver`.`major` `m`
         join `webserver`.`class` `c`
where ((`i`.`INS_ID` = `m`.`INS_ID`) and (`m`.`MAJOR_ID` = `c`.`MAJOR_ID`));

