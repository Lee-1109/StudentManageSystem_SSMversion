create definer = root@localhost view v_course as
select `v`.`INS_ID`      AS `INS_ID`,
       `v`.`INS_NAME`    AS `INS_NAME`,
       `v`.`MAJOR_ID`    AS `MAJOR_ID`,
       `v`.`MAJOR_NAME`  AS `MAJOR_NAME`,
       `t`.`TEA_ID`      AS `TEA_ID`,
       `t`.`TEA_NAME`    AS `TEA_NAME`,
       `c`.`COUR_ID`     AS `COUR_ID`,
       `c`.`COUR_NAME`   AS `COUR_NAME`,
       `c`.`COUR_PERIOD` AS `COUR_PERIOD`,
       `c`.`COUR_CREDIT` AS `COUR_CREDIT`
from ((`webserver`.`v_ins_maj` `v` join `webserver`.`teacher` `t`)
         join `webserver`.`course` `c`)
where ((`c`.`MAJOR_ID` = `v`.`MAJOR_ID`) and (`c`.`TEA_ID` = `t`.`TEA_ID`));

