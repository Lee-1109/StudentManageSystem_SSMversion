create
    definer = root@localhost procedure proc_stuGetAllCourseGrade(IN V_ID varchar(255))
BEGIN
SELECT v.COUR_ID,v.COUR_NAME,v.CLASS_ID,v.STU_ID,v.STU_NAME,v.GRADE FROM v_grade v
where  v.STU_ID=V_ID;
END;

