create definer = root@localhost trigger tg_insert_teacher
    after insert
    on teacher
    for each row
begin
insert into login values(new.TEA_ID,new.TEA_ID,1);
END;

