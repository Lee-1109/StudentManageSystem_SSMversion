create definer = root@localhost trigger tg_delete_student
    after delete
    on student
    for each row
begin
delete from login where ID=OLD.STU_ID;
END;

