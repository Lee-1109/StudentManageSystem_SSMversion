create
    definer = root@localhost procedure proc_GetClassInsMajor(IN CLASSID varchar(255))
begin
    select INS_ID,INS_NAME,MAJOR_ID,MAJOR_NAME,CLASS_ID
        FROM v_ins_maj_cla
    where CLASS_ID=CLASSID;
    end;

