create
    definer = root@localhost procedure proc_GetUserById(IN V_ID varchar(255))
begin
select ID,PASSWORD,TYPE
FROM login
where ID=V_ID;
end;

