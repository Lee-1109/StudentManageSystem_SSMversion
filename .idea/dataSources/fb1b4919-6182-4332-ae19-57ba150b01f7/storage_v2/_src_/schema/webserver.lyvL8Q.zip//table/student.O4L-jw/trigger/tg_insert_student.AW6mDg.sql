create definer = root@localhost trigger tg_insert_student
    after insert
    on student
    for each row
begin
insert into login values(new.STU_ID,new.STU_ID,0);
update class set CAPACITY=CAPACITY+1 where CLASS_ID=new.CLASS_ID;
END;

