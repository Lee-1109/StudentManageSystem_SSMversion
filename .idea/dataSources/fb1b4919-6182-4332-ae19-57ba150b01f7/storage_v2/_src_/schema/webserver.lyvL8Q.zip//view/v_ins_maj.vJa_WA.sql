create definer = root@localhost view v_ins_maj as
select `i`.`INS_ID`     AS `INS_ID`,
       `i`.`INS_NAME`   AS `INS_NAME`,
       `m`.`MAJOR_ID`   AS `MAJOR_ID`,
       `m`.`MAJOR_NAME` AS `MAJOR_NAME`
from `webserver`.`institute` `i`
         join `webserver`.`major` `m`
where (`m`.`INS_ID` = `i`.`INS_ID`);

